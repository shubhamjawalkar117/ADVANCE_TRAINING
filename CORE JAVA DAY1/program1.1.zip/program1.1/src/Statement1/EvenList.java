package Statement1;

import java.util.Scanner;

public class EvenList {

	public static void main(String[] args) {
		int n;
		Scanner in =new Scanner(System.in);
		n=in.nextInt();
		System.out.println("Even numbers from 1 to "+n+" are:");
		for(int i=1;i<=n;i++) {
			if(i%2==0) {
				System.out.println(i+"");
				
			}
		}

	}

}